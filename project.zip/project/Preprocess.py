from collections import Counter
from torchtext.vocab import build_vocab_from_iterator
from torchtext.data.utils import get_tokenizer
import pandas as pd
import torch
from torch.utils.data import DataLoader, Dataset
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence, pad_sequence
import torch.nn as nn
import torch.optim as optim
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import matplotlib.pyplot as plt

class Preprocess:
    def __init__(self, df):
        self.df = df
        self.tokenizer = None
        self.vocab = None

    # Preprocess the text column and remove NaN values
    def prepare(self):
        self.df = self.df.dropna()
        self.df.dropna(subset=['text'], inplace=True)
        self.df['text'] = self.df['text'].apply(lambda x: x.lower())
        return self.df
    
    def tokenize(self):
        self.tokenizer = get_tokenizer('basic_english')
        counter = Counter()
        for line in self.df['text']:
            counter.update(self.tokenizer(line))

    def yield_tokens(self):
        for text in self.df:
            yield self.tokenizer(text)
    
    # Build the vocabulary
    def buildVocabulary(self):
        specials = ['<unk>', '<pad>', '<bos>', '<eos>']
        vocab = build_vocab_from_iterator(self.yield_tokens(), specials=specials)
        vocab.set_default_index(vocab['<unk>'])
        return vocab
    
    # Encode labels
    def labelEncoding(self):
        le = LabelEncoder()
        self.df['label'] = le.fit_transform(self.df['sentiment'])
        return le, self.df
    
    def collate_batch(self, batch):
        label_list, text_list, lengths_list = [], [], []
        for (_text, _label) in batch:
            # Ensure that the text sequence is not empty
            if len(_text) > 0:
                label_list.append(_label)
                lengths_list.append(len(_text))
                text_list.append(_text)
        # Make sure that there is at least one sequence to process
        if len(label_list) == 0:
            return torch.tensor([]), torch.tensor([]), torch.tensor([])
        text_list = pad_sequence(text_list, padding_value=0, batch_first=True)
        return torch.tensor(label_list, dtype=torch.int64), text_list, torch.tensor(lengths_list, dtype=torch.int64)




